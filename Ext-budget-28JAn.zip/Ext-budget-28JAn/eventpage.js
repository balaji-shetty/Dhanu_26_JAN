var contextMenuItem = {
    "id": "spendMoney",
    "title": "Spend Money",
    "contexts": ["selection"]
};

// Create context menu
chrome.contextMenus.create(contextMenuItem);

// Context menu click handler
chrome.contextMenus.onClicked.addListener(function (info, tab) {
    if (info.menuItemId === "spendMoney") {
        // Handle the context menu click event
        console.log("Spend Money context menu clicked!");
        // You can add your logic here
    }
});
