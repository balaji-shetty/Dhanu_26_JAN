chrome.runtime.onInstalled.addListener(function () {
    // Context menu item
    var contextMenuItem = {
      "id": "simpleContextMenu",
      "title": "Click me!",
      "contexts": ["page"]
    };
  
    // Create context menu
    chrome.contextMenus.create(contextMenuItem);
  });
  
  // Context menu click handler
  chrome.contextMenus.onClicked.addListener(function (info, tab) {
    if (info.menuItemId === "simpleContextMenu") {
      // Handle the context menu click event
      alert("You clicked the context menu!");
    }
  });
  